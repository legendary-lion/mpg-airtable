<div class="container mt-5 pt-5">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <h5 class="text-center mb-4">Sync Today's Live Data</h5>
            <button id="sync_live_submit" class="btn btn-primary w-100 mb-4">Sync Today's Data</button>
        </div>
    </div>
    <div class="row my-4">
        <div class="col-md-6 offset-md-3">
            <div class="row">
                <div class="col"><hr></div>
                <div class="col-auto">OR</div>
                <div class="col"><hr></div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <h5 class="text-center mb-4">Sync by Date</h5>
            <input id="sync_date" name="sync_date" class="form-control mb-4" type="date"/>
            <button id="sync_date_submit" class="btn btn-primary w-100 mb-4">Start Sync</button>
        </div>
    </div>
</div>
<div class="spinner-overlay d-none">
    <h3>Syncing...</h3><br/>
    <div class="spinner-border" role="status"></div>
</div>
<div class="container mb-5 pb-5">
    <div class="row">
        <div class="col-md-12">
            <hr>
            <h5 class="text-center">Log</h5>
            <pre id="log_view"></pre>
        </div>
    </div>
</div>
<style>
    pre {
        background-color: #f0f0f0;
        min-height: 400px;
        height: 400px;
        resize: both;
        width: 100%;
        overflow: scroll;
        font-size: 11px;
    }
    .spinner-overlay {
        background-color: rgba(255,255,255,.8);
        display:flex;
        z-index:999;
        flex-direction: column;
        position: fixed;
        align-items:center;
        justify-content: center;
        height: 100vh;
        width: 100vw;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
    }
</style>
<script>
    $('#sync_live_submit').on('click', function(e) {
        $('.spinner-overlay').removeClass('d-none');
        // - 14400 (4 hours) for EST Timezone correction
        var timestamp = Math.floor(Date.now() / 1000 - 14400); 
        $.ajax({
            url: "data-sync.php",
            type: "GET",
            data: {
                datetime: timestamp
            },
            success: function (response) {
                var result = JSON.parse(response);
                $('#log_view').html(result.data);
                $('.spinner-overlay').addClass('d-none');
            },
            error: function (xhr, ajaxOptions, thrownError) {
                $('#log_view').html(thrownError);
                $('.spinner-overlay').addClass('d-none');
            }
        }); // END AJAX
    });
    $('#sync_date_submit').on('click', function(e) {
        $('.spinner-overlay').removeClass('d-none');
        var date = new Date($('#sync_date').val());
        // + 43200 (12 hours) for midday
        var timestamp = Math.floor(date.getTime() / 1000 + 43200);
        // console.log(timestamp);
        $.ajax({
            url: "data-sync.php",
            type: "GET",
            data: {
                datetime: timestamp
            },
            success: function (response) {
                var result = JSON.parse(response);
                $('#log_view').html(result.data);
                $('.spinner-overlay').addClass('d-none');
            },
            error: function (xhr, ajaxOptions, thrownError) {
                $('#log_view').html(thrownError);
                $('.spinner-overlay').addClass('d-none');
            }
        }); // END AJAX
    });
</script>